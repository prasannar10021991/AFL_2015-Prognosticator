from . import view

if __name__ == '__main__':
    view.main()
