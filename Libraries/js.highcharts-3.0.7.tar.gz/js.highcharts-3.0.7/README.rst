js.highcharts
=============

Introduction
------------

This library packages `Highcharts`_ for `fanstatic`_.

This requires integration between your web framework and ``fanstatic``,
and making sure that the original resources (shipped in the ``resources``
directory in ``js.highcharts``) are published to some URL.

**Highcharts is not free for commercial use!**
Please make sure to read the `licensing information`_!

.. _`fanstatic`: http://fanstatic.org
.. _`Highcharts`: http://www.highcharts.com/
.. _`licensing information`: http://shop.highsoft.com/highcharts.html
